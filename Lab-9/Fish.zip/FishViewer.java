import javax.swing.JFrame;

public class FishViewer {
	public static void main(String[] args) {
		JFrame frame = new FishFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Fish");
		frame.setVisible(true);
	}
}
